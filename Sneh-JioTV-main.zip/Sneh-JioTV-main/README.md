<p align="center"><img src="https://i.ibb.co/hmZyP5j/JIO-LOGO-removebg-preview.png" width="180" height="100"></p>

<h1 align='center'>✯ JɪᴏTV Pʟᴀʏ ✯</h1>

<!-- DO NOT EDIT FILE AND ADD YOU NAME HERE AND PUBLISH -->
<!-- © 2021 TechieSneh -->

<h4 align='center'>📺 The PHP Script For Streaming JioTV Links and Play 📺 <br>🌟 Start This Repositry Befor Copying 😎<br>😠 Don't Remove Credits<br>Don't Edit This Script 😈<br><br>Visit Our Site & Enjoy</h4>
<br>

<p align="center"><b> ✅ SERVER IS UP NOW ✅ </b></p><br>
<!--  <p align="center"><b> ❗ SERVER IS UNDER MAINTENANCE ❗ </b></p><br>  -->

<h2>😇 Features :</h2>

- HQ Streaming Free of Cost <br>
- Will Works In 250, 400, 600, 800 in this Gives Qualities
- Jio Quality Change Option Added
- Web Play Supports


<br>
<h2> 📡 Watch JioTv Here : </h2>
[Sneh JioTV v3.3.0] (https://github.com/techiesneh/Sneh-JioTV/raw/main/Sneh_JioTv_3.3.0.apk)<br>
[Sneh JioTv Site] (https://snehtv.tk/jiotv)<br><br>

- `Watch All Channels of JioTV` 
- `Quality Change Option Added`

<br>
<h2> 📡 Watch SnehTv Here : </h2>
[Sneh TV v10.3.0] (https://github.com/techiesneh/Sneh-TV/raw/main/Sneh_TV_10.3.0.apk)<br>
[Use Our Site] (https://snehtv.tk/)<br><br>


  
<br>
<h2>😛 Generate ssoToken Here : </h2>

- For This You Need JioID Number and Password

[Jio Login Page] (http://jiologin.epizy.com)
 
- `user` = Username / Mobile No.
- `pass` = Password


<br>
<h2>🍁 How To Run : </h2>

#### ♢ Method 1 :

• Put Your ssoToken in Files then
• Locate all Files in LocalHost Root Folder <br>
• Open localhost You Will See all Channels List <br>
• Click On Channel and Play <br>


## 🍁 Given Below Are Some Screenshots Of Sneh JioTV 
<br>

## 🖥 Desktop Version
<br>

<div>
<img src="images/desktop/desk1.png" alt="Desktop 1" width="320" height="180">
<img src="images/desktop/desk2.png" alt="Desktop 2" width="320" height="180"><br>
<img src="images/desktop/desk3.png" alt="Desktop 3" width="320" height="180">
<img src="images/desktop/desk4.png" alt="Desktop 4" width="320" height="180"><br>
<img src="images/desktop/desk5.png" alt="Desktop 5" width="320" height="180">

</div>



<br>
<h2> Where To Play : </h2>
<h5 align="center"> Play From App <a href="https://github.com/techiesneh/Sneh-JioTV/raw/main/Sneh_JioTv_3.3.0.apk">Sneh JioTV v3.3.0</a> <br> or Otherwise Use Our Site https://snehtv.tk/jiotv
  
<br>
<h2>🚸 Warnings :</h2>

- This is Just For Educational Purpose
- DO NOT Sell this Script, This is 💯% Free

<h3>🤗 Meet Me : </h3>

• For any Support About Script contact [@TechieSneh]
• Or Contact at [techiesneh@protonmail.com](mailto:techiesneh@protonmail.com)

<br>


---
<h4 align='center'>© 2021 Techie Sneh</h4>

<!-- DO NOT REMOVE THIS CREDIT 🤬 🤬 -->

