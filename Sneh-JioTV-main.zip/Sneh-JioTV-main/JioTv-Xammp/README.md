<p align="center"><img src="https://i.ibb.co/hmZyP5j/JIO-LOGO-removebg-preview.png" width="180" height="100"></p>

<h1 align='center'>✯ JɪᴏTV Pʟᴀʏ ✯</h1>

<!-- DO NOT EDIT FILE AND ADD YOU NAME HERE AND PUBLISH -->
<!-- © 2021 TechieSneh -->

<h4 align='center'>📺 The PHP Script For Grabb Streaming Links and Play it , This Workes Only on Indian Server and LocalHost [ VPS ] due to Geo-restrictions<br><br>🌟 Start This Repositry Befor Copying 😎<br>😠 Don't Remove Creadits<br>Don't Edit This Script 😈<br><br>Put Your Own Token In This Script</h4>
<br>

<h2>😇 Features :</h2>

- HQ Streaming Free of Cost <br>
- Will Works In 250, 400, 600, 800 in this Gives Qualities
- Web Play Supports
- TiviMate or PC Users can Also Use This [PlayList.m3u](https://github.com/techiesneh/Sneh-JioTV/blob/main/playlist.m3u)

<h3>😛 Generate ssoToken Here :</h3>

- For This You Need JioID Number and Password

[Jio Login Page] (http://jiologin.epizy.com)
 
- `user` = Username / Mobile No.
- `pass` = Password


<br>
<h2>🍁 How To Use : </h2>

#### ♢ Method 1 :

• Put Your ssoToken in Files then
• Locate all Files in LocalHost Root Folder <br>
• Open localhost You Will See all Channels List <br>
• Click On Channel and Play <br>

#### ♢ Method 2 :

• In Player Put Links Format Like Below

  ```py
  [+] - http://localhost/m3u8.php?c=Channel_Name&q=Quality&e=play.m3u8
  
  [+] - http://localhost/m3u8.php?c=And_Pictures_HD&q=800&e=play.m3u8
  
  ```

   ♢ <b>Depnding on Your Server Change Links<br>
   ♢ This Script is free for USE and Modify</b><br><br>

<h2>🚸 Warnings :</h2>

- This is Just For Educational Purpose
- DO NOT Sell this Script, This is 💯% Free

<h3>🤗 Meet Me : </h3>


• For any Support About Script contact [@TechieSneh]
• Or Contact at [techiesneh@protonmail.com](mailto:techiesneh@protonmail.com)

<br>


---
<h4 align='center'>© 2021 Techie Sneh</h4>

<!-- DO NOT REMOVE THIS CREDIT 🤬 🤬 -->

